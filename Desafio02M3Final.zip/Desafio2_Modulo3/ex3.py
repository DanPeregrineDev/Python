def celciusToFarenheit(t):
    result = (9 * t / 5) + 32

    return result

def farenheitToCelcius(t):
    result = 5 * (t - 32) / 9

    return result
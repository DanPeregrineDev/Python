def soma_quadrados(n):
    soma = 0
    for i in range(0, n):
        soma = i ** 2
    return soma
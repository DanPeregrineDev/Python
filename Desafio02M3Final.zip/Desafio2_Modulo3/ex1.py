def hipotenusa(c1, c2):
    import math

    h = math.sqrt((c1 ** 2) + (c2 ** 2))

    return h
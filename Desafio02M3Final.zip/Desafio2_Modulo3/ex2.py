def square(n):
    r = n * n

    return r